# TP Ransomware Grupo 04 - Criptografia y Seguridad Informatica (86.36)

## Alumno, mail, padron, user: 
* **Aguirre Pedro**, paguirre@fi.uba.ar, 97603, PedroAguirre23
* **Fernandez Irungaray Martina**, mafernandez@fi.uba.ar, 99611, martina-fi
* **Sobico Carla**, csobico@fi.uba.ar, 99738, CarlaSobico
* **Vazquez Rodrigo**, rvazquez@fi.uba.ar, 98934, rodrigovzq

Para desencriptar los archivos:
1) El archivo de llave privada "privKey.pem" debe ubicarse en la carpeta \keys
2) El script "decrypter.py" debe ubicarse en la carpeta Demo y ejecutarse

